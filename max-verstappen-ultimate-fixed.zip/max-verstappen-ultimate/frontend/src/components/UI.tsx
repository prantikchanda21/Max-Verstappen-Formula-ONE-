import {Component,type ReactNode,useEffect,useRef,useState} from 'react';
import {ArrowUpRight,RefreshCw} from 'lucide-react';
import {useSettings} from '../stores/settings';
import type {DataEnvelope} from '../../../shared/data';
export function PageHeader({index,title,accent,description}:{index:string;title:string;accent:string;description:string}){return <header className="page-header"><div className="eyebrow"><span className="red-line"/>{index} / THE VERSTAPPEN FILE</div><h1>{title}<br/><em>{accent}</em></h1><p>{description}</p></header>}
export function Panel({children,className=''}:{children:ReactNode;className?:string}){return <section className={`panel ${className}`}>{children}</section>}
export function Source({data}:{data?:DataEnvelope}){return data?<div className="source"><span className={`status-dot ${data.source==='jolpica'?'green':''}`}/>{data.source==='jolpica'?'Jolpica / recently retrieved':data.source==='bundled'?'Bundled snapshot':'Cached snapshot'} · {new Date(data.updatedAt).toLocaleString()} {data.partial&&' · PARTIAL DATA'}<a href={data.sourceUrl} target="_blank" rel="noreferrer">Source <ArrowUpRight size={12}/></a>{data.warning&&<span className="source-note">{data.warning}</span>}</div>:null}
export function Loading(){return <div className="skeleton" role="status" aria-label="Loading data"><span/><span/><span/></div>}
export function Failure({message,retry}:{message:string;retry?:()=>void}){return <div className="empty" role="alert"><h3>Data unavailable</h3><p>{message}</p>{retry&&<button onClick={retry}><RefreshCw size={14}/> Retry</button>}</div>}
export function SeasonSelect({value,onChange}:{value:number;onChange:(n:number)=>void}){return <label>Season<select value={value} onChange={e=>onChange(+e.target.value)}>{Array.from({length:new Date().getFullYear()-2014},(_,i)=>new Date().getFullYear()-i).map(y=><option key={y}>{y}</option>)}</select></label>}
export function Metric({value,label,detail}:{value:string|number;label:string;detail?:string}){
 const animated=useRef(false),ref=useRef<HTMLDivElement>(null),motion=useSettings(s=>s.motion),[display,setDisplay]=useState(value);
 useEffect(()=>{setDisplay(value);if(animated.current||!motion||!/^\d+(\.\d+)?$/.test(String(value))||!ref.current)return;let frame=0;const numeric=Number(value),decimals=String(value).split('.')[1]?.length??0;
 const io=new IntersectionObserver(([entry])=>{if(!entry.isIntersecting)return;io.disconnect();animated.current=true;const start=performance.now();const step=(now:number)=>{const t=Math.min(1,(now-start)/950);setDisplay((numeric*(1-Math.pow(1-t,3))).toFixed(decimals));if(t<1)frame=requestAnimationFrame(step)};frame=requestAnimationFrame(step)},{threshold:.3});io.observe(ref.current);return()=>{io.disconnect();cancelAnimationFrame(frame)}},[value,motion]);
 return <div className="metric" ref={ref}><strong>{display}</strong><span>{label}</span>{detail&&<small>{detail}</small>}</div>
}
export class Boundary extends Component<{children:ReactNode;fallback?:ReactNode},{error:boolean}>{state={error:false};static getDerivedStateFromError(){return {error:true}}render(){return this.state.error?(this.props.fallback??<Failure message="This view could not render. Reload the page or use a different browser."/>):this.props.children}}
