import {useQuery} from '@tanstack/react-query';
import type {DataEnvelope,Kind} from '../../../shared/data';
export async function api<T>(url:string,options?:RequestInit):Promise<T>{
 const r=await fetch(url,{...options,signal:options?.signal??AbortSignal.timeout(26000)});let d:any;try{d=await r.json()}catch{throw new Error(`API not reachable (HTTP ${r.status}). The backend returned a non-JSON response; check /api/health.`)}if(!r.ok)throw new Error(typeof d.error==='string'?d.error:'Request failed');return d as T;
}
export function useRacing(kind:Kind,season:number){return useQuery({queryKey:[kind,season],queryFn:({signal})=>api<DataEnvelope>(`/api/${kind}?season=${season}`,{signal}),staleTime:15*60*1000,retry:1})}
