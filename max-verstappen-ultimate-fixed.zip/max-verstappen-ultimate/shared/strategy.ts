import {z} from 'zod';
export const strategySchema=z.object({laps:z.number().int().min(10).max(100),base:z.number().min(40).max(200),pit:z.number().int().min(2),second:z.number().int().min(3),pitLoss:z.number().min(0).max(60),degradation:z.number().min(0).max(1),compound:z.enum(['soft','medium','hard']),temperature:z.number().min(10).max(65),weather:z.enum(['dry','damp','wet']),neutralization:z.enum(['none','sc','vsc']),neutralLap:z.number().int().min(1),traffic:z.number().min(0).max(3),fuel:z.number().min(0).max(.1),pace:z.number().min(-3).max(3),seed:z.number().int().min(1).max(100000)}).superRefine((p,c)=>{if(p.pit>=p.laps||p.second>=p.laps||p.second<=p.pit||p.neutralLap>p.laps)c.addIssue({code:'custom',message:'Pit laps must be ordered and before the finish; neutralization must occur within the race.'})});
export type StrategyInput=z.infer<typeof strategySchema>;
export const defaults:StrategyInput={laps:57,base:92,pit:20,second:38,pitLoss:22,degradation:.12,compound:'medium',temperature:35,weather:'dry',neutralization:'none',neutralLap:20,traffic:.2,fuel:.035,pace:0,seed:42};
export function simulate(input:StrategyInput){
 const p=strategySchema.parse(input);
 function run(stops:number[],noise=0){let total=0,age=0;const cumulative:number[]=[],lapTimes:number[]=[],tyreAge:number[]=[];let compound=p.compound;
  for(let lap=1;lap<=p.laps;lap++){
   const neutral=p.neutralization!=='none'&&lap>=p.neutralLap&&lap<p.neutralLap+(p.neutralization==='sc'?3:2);
   if(stops.includes(lap)){total+=p.pitLoss*(neutral?(p.neutralization==='sc'?.55:.7):1);age=0;compound=lap===stops.at(-1)?'hard':'medium'}
   const factor={soft:1.45,medium:1,hard:.65}[compound],offset={soft:-.65,medium:0,hard:.6}[compound];
   const deg=p.degradation*factor*age*(1+age/35)*(1+Math.abs(p.temperature-35)/60);
   const weather={dry:0,damp:4,wet:13}[p.weather];
   const traffic=age<3&&lap>1?p.traffic:0;
   const seconds=(p.base+p.pace+offset+deg+p.fuel*(p.laps-lap)+weather+traffic+noise)*(neutral?(p.neutralization==='sc'?1.4:1.25):1);
   total+=seconds;cumulative.push(total);lapTimes.push(seconds);tyreAge.push(age);age++;
  }return {total,cumulative,lapTimes,tyreAge,stops};
 }
 const one=run([p.pit]),two=run([p.pit,p.second]);let seed=p.seed;
 const random=()=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/4294967296};
 const distribution=Array.from({length:120},()=>run([p.pit],(random()-.5)*.8).total).sort((a,b)=>a-b);
 return {one,two,delta:two.cumulative.map((n,i)=>n-one.cumulative[i]),distribution,interval:[distribution[6],distribution[113]],label:'Illustrative model. Not a race prediction.',assumptions:'Linear/quadratic tyre age; fixed compound offsets; linear fuel burn; simplified weather and neutralization. Monte Carlo varies race-wide pace ±0.4 s/lap with a reproducible seed.'};
}
