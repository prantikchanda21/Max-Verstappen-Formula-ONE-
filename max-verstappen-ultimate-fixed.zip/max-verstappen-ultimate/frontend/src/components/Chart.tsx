import {useEffect,useRef} from 'react';
import * as echarts from 'echarts/core';
import {LineChart,BarChart} from 'echarts/charts';
import {GridComponent,TooltipComponent,LegendComponent,DataZoomComponent,MarkLineComponent} from 'echarts/components';
import {CanvasRenderer} from 'echarts/renderers';
import type {EChartsCoreOption} from 'echarts/core';
import {useSettings} from '../stores/settings';
echarts.use([LineChart,BarChart,GridComponent,TooltipComponent,LegendComponent,DataZoomComponent,MarkLineComponent,CanvasRenderer]);
export default function Chart({option,label,height=300}:{option:EChartsCoreOption;label:string;height?:number}){
 const el=useRef<HTMLDivElement>(null),chart=useRef<echarts.EChartsType|null>(null),motion=useSettings(s=>s.motion);
 useEffect(()=>{if(!el.current)return;const c=echarts.init(el.current);chart.current=c;const ro=new ResizeObserver(()=>c.resize());ro.observe(el.current);return()=>{ro.disconnect();c.dispose()}},[]);
 useEffect(()=>{chart.current?.setOption({backgroundColor:'transparent',color:['#f34a40','#7cbaff','#dfd8bd','#8dd3b1'],textStyle:{color:'#e6ecf5',fontFamily:'Barlow, Arial, sans-serif',fontWeight:800},animation:motion,grid:{left:55,right:25,top:50,bottom:55},tooltip:{trigger:'axis',backgroundColor:'rgba(6,8,14,.88)',borderColor:'rgba(255,255,255,.18)',textStyle:{color:'#fff',fontWeight:800}},legend:{textStyle:{color:'#e6ecf5',fontWeight:800}},...option},{notMerge:false,replaceMerge:['series']})},[option,motion]);
 return <div ref={el} style={{height,width:'100%'}} role="img" aria-label={label}/>;
}
export function axes(labels:(string|number)[],unit=''){return {xAxis:{type:'category',data:labels,axisLine:{lineStyle:{color:'#5b6679'}},axisLabel:{color:'#e6ecf5',fontWeight:800}},yAxis:{type:'value',name:unit,axisLabel:{color:'#e6ecf5',fontWeight:800},nameTextStyle:{color:'#e6ecf5',fontWeight:800},splitLine:{lineStyle:{color:'rgba(255,255,255,.1)'}}}}}
