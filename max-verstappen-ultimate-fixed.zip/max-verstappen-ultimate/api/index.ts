// A single Node.js Vercel Function. No production port listener.
export {default} from '../backend/src/app.js';
