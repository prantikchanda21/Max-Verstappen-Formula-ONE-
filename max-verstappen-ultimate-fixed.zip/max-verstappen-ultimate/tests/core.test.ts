import {beforeEach,afterEach,describe,it,expect,vi} from 'vitest';
import request from 'supertest';
import app from '../backend/src/app';
import {clearCache,racing} from '../backend/src/providers/racing';
import {fetchPages} from '../backend/src/providers/pagination';
import {defaults,simulate} from '../shared/strategy';
import {ProviderSchema} from '../shared/data';
import snapshots from '../datasets/historical/snapshots.json';
beforeEach(()=>{process.env.DATA_OFFLINE='true';delete process.env.GROQ_API_KEY;clearCache()});
afterEach(()=>vi.unstubAllGlobals());
describe('API contracts',()=>{
 it('health and JSON 404',async()=>{expect((await request(app).get('/api/health')).body.status).toBe('ok');const r=await request(app).get('/api/missing');expect(r.status).toBe(404);expect(r.headers['content-type']).toContain('json')});
 it('rejects invalid seasons and chat input',async()=>{expect((await request(app).get('/api/results?season=abc')).status).toBe(400);expect((await request(app).post('/api/ai/chat').send({message:''})).status).toBe(400)});
 it('falls back without relabeling the requested season',async()=>{const r=await request(app).get('/api/results?season=2024&round=1');expect(r.status).toBe(200);expect(r.body.source).toBe('bundled');expect(r.body.season).toBe(2024);expect(r.body.races).toHaveLength(1);expect(r.body.races[0].Results[0].Driver.driverId).toBe('max_verstappen')});
 it('unavailable seasons fail explicitly',async()=>expect((await request(app).get('/api/calendar?season=1950')).status).toBe(503));
 it('deterministic AI fallback includes retrieved source',async()=>{const r=await request(app).post('/api/ai/chat').send({message:'Summarize race results',season:2024,round:1});expect(r.status).toBe(200);expect(r.body.mode).toBe('deterministic');expect(r.body.sources[0]).toContain('bundled');expect(r.body.answer).toContain('Max Verstappen')});
 it('Groq failure falls back and the key stays server-side',async()=>{process.env.GROQ_API_KEY='test-secret';vi.stubGlobal('fetch',vi.fn().mockResolvedValue(new Response('{}',{status:429})));const r=await request(app).post('/api/ai/chat').send({message:'2023 wins',season:2023});expect(r.body.mode).toBe('deterministic');expect(JSON.stringify(r.body)).not.toContain('test-secret')});
});
describe('data quality',()=>{
 it('every bundled snapshot validates',()=>{for(const s of Object.values(snapshots))expect(ProviderSchema.safeParse(s.payload).success).toBe(true)});
 it('2024 archive contains all 24 rounds and 9 Max victories',async()=>{const d=await racing(2024,'results');expect(d.races).toHaveLength(24);expect(d.races.filter(r=>r.Results?.some(x=>x.Driver.driverId==='max_verstappen'&&x.position==='1'))).toHaveLength(9);expect(d.partial).toBe(false)});
 it('merges races split across provider pages',async()=>{const raw=structuredClone(snapshots['2024/results'].payload);const original=raw.MRData.RaceTable.Races[0];const pages=[0,1].map(i=>({...raw,MRData:{...raw.MRData,total:'2',limit:'1',offset:String(i),RaceTable:{...raw.MRData.RaceTable,Races:[{...original,Results:original.Results.slice(i,i+1)}]}}}));let i=0;const merged=await fetchPages('https://example.com/results.json?limit=1',async()=>pages[i++]);expect(merged.MRData.RaceTable?.Races[0].Results).toHaveLength(2)});
 it('deduplicates concurrent requests and caches verified responses',async()=>{process.env.DATA_OFFLINE='false';const mock=vi.fn().mockResolvedValue(new Response(JSON.stringify(snapshots['2024/calendar'].payload)));vi.stubGlobal('fetch',mock);await Promise.all([racing(2024,'calendar'),racing(2024,'calendar')]);expect(mock).toHaveBeenCalledTimes(1);expect((await racing(2024,'calendar')).source).toBe('jolpica')});
});
describe('strategy',()=>{
 it('is reproducible and bounded',()=>{const a=simulate(defaults),b=simulate(defaults);expect(a).toEqual(b);expect(a.one.cumulative).toHaveLength(defaults.laps);expect(a.distribution).toHaveLength(120);expect(a.one.total).toBeGreaterThan(0)});
 it('pit loss increases total and invalid stop order is rejected',()=>{expect(simulate({...defaults,pitLoss:30}).one.total-simulate({...defaults,pitLoss:20}).one.total).toBeCloseTo(10);expect(()=>simulate({...defaults,second:10})).toThrow()});
 it('neutralization reduces the marginal pit-loss cost only during its window',()=>{const p={...defaults,neutralization:'sc' as const,neutralLap:defaults.pit};expect(simulate({...p,pitLoss:30}).one.total-simulate({...p,pitLoss:20}).one.total).toBeCloseTo(5.5)});
});
