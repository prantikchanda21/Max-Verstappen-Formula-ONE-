# Validation report

This report distinguishes checks that ran from capabilities not verified here.

| Check | Outcome |
|---|---|
| Dependency installation with lockfile | Completed |
| Strict TypeScript (`npm run typecheck`) | Passed |
| ESLint (`npm run lint`) | Passed |
| Production Vite build (`npm run build`) | Passed |
| Vitest / Supertest core suite | 13 tests passed (14 total with production-shell test) |
| Production-shell / routing-order smoke test | Passed (1 test; 12 deep links, API 404 and emitted assets) |
| All bundled source tables parse against Zod | Passed |
| 2024 results contain 24 rounds and 9 Max wins | Passed |
| Telemetry samples | VER: 318; LEC: 342; recorded Bahrain 2023 qualifying |
| Local development server startup | Started by Playwright harness; health probe succeeded |
| Playwright desktop/mobile scenarios | **Blocked before execution**: Chromium executable absent; browser CDN download returned invalid/truncated archive |
| Visual review / GPU behavior | **Not verified in a browser here** |
| Live Groq success | **Not verified**: no user Groq key supplied |
| Groq no-key / failure behavior | Passed deterministic fallback tests |
| Authenticated `vercel dev`, Vercel build and production deployment | **Not run**: no linked/authenticated Vercel project |
| Windows `.bat` execution | Supplied and reviewed; not executable in this Linux environment |

A live retrieval attempt in this sandbox fell back to a complete bundled calendar within the request budget; successful runtime network retrieval was not established here. Snapshot ingestion did reach Jolpica and retrieve all pages.

The initial test run revealed a provider-schema case (unranked drivers missing `position`) and incomplete paginated snapshots. Both were corrected before the final run.

## Core coverage

JSON health/404 behavior, invalid seasons/chat inputs, same-season fallback, unavailable seasons, deterministic AI responses and Groq failure, provider schemas, complete 2024 results, pagination across a split race, concurrent request deduplication, deterministic strategy, pit loss arithmetic and SC pit-loss adjustments.

## Browser scenarios supplied

The Playwright suite contains six scenarios for each desktop/mobile project: all routes and overflow checks; race classifications and fallback; strategy input/validation; telemetry scrubbing; garage control state; deterministic AI response. These did not execute because browser launch failed. Do not interpret the twelve launch failures as page assertions passing or failing.

Run locally:

```sh
npm ci
npm run build
npm test
npx playwright install chromium
npm run test:e2e
```

Then test high/low 3D quality, reduced motion, capture, fullscreen, touch orbit, chart zoom and direct route refresh in a real browser. An actual Vercel preview deployment is needed to verify platform rewrite behavior; the local production-shell test verifies the intended matching order and shell/assets, not Vercel itself.
