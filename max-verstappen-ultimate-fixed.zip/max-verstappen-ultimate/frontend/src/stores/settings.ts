import {create} from 'zustand';
import {persist} from 'zustand/middleware';
interface Settings {quality:'low'|'high';motion:boolean;setQuality:(v:'low'|'high')=>void;setMotion:(v:boolean)=>void}
export const useSettings=create<Settings>()(persist(set=>({quality:'high',motion:true,setQuality:quality=>set({quality}),setMotion:()=>set({motion:true})}),{name:'mv-settings',partialize:s=>({quality:s.quality}),merge:(saved,cur)=>({...cur,...(saved as object),motion:true})}));
