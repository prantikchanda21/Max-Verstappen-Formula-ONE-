export const weekend=[
 {step:'01',title:'Practice',text:'Teams run three one-hour sessions on a standard weekend to learn the track, test tyres and set up the car. Sprint weekends compress this to a single practice.'},
 {step:'02',title:'Qualifying',text:'Three knockout sessions, Q1, Q2 and Q3, cut the field from 20 to 15 to 10. The fastest lap in Q3 earns pole position.'},
 {step:'03',title:'Sprint (some weekends)',text:'A short race of about 100 km with its own qualifying session and reduced points. It adds a second competitive result to selected weekends.'},
 {step:'04',title:'Grand Prix',text:'The race covers at least 305 km (Monaco is shorter) and must finish within two hours. Strategy, tyres and traffic decide most outcomes.'}
];
export const points={race:[25,18,15,12,10,8,6,4,2,1],sprint:[8,7,6,5,4,3,2,1],note:'Race points go to the top ten finishers. A bonus point for fastest lap existed through 2024 and was removed from 2025.'};
export const tyres=[
 {name:'Soft',colour:'#ef4a3f',text:'Fastest over one lap, wears quickly. Common for qualifying and short stints.'},
 {name:'Medium',colour:'#e9c94a',text:'A balance of pace and life, often the flexible choice for strategy.'},
 {name:'Hard',colour:'#e8ecf2',text:'Slowest to switch on, longest lasting. Suits long stints and hot tracks.'},
 {name:'Intermediate',colour:'#59b36a',text:'Grooved tyre for damp or drying tracks.'},
 {name:'Full wet',colour:'#4f8fe0',text:'For heavy rain, it clears the most water at the cost of speed.'}
];
export const tyreNote='Pirelli supplies every team. Each race weekend nominates three dry compounds from its range. In a dry race a driver must use at least two different dry compounds, which is why pit stops matter.';
export const flags=[
 {name:'Green',colour:'#3dbb68',text:'Track clear. Racing resumes.'},
 {name:'Yellow',colour:'#f1d33c',text:'Danger ahead. Slow down and no overtaking.'},
 {name:'Red',colour:'#e0382d',text:'Session stopped. Cars return to the pit lane.'},
 {name:'Blue',colour:'#4a8fe6',text:'A faster car is behind. Let it pass.'},
 {name:'Chequered',colour:'#d9dee6',text:'The session has ended.'}
];
export const technology=[
 {title:'Power unit',text:'Since 2014 cars use a 1.6-litre V6 turbo hybrid with energy recovery systems. New power unit rules arrive in 2026 with a much larger electrical share.'},
 {title:'Ground effect',text:'Regulations introduced for 2022 returned to underfloor tunnels that generate downforce, making it easier for cars to follow closely. Red Bull mastered the formula early.'},
 {title:'DRS',text:'A driver within one second of the car ahead at a detection point may open the rear wing flap in designated zones to reduce drag and help overtaking.'},
 {title:'Halo',text:'A titanium cockpit protection structure made mandatory in 2018 and credited with preventing serious injuries.'},
 {title:'Pit stops',text:'A modern stop takes about two seconds stationary. The record is 1.80 seconds, set by McLaren in Qatar in 2023. The time lost driving through the pit lane is added on top.'},
 {title:'Safety car',text:'When the track is unsafe, a safety car bunches the field and speed limits apply. A virtual safety car enforces a delta time without bunching cars. Both reshape strategy.'}
];
export const redBull=[
 {year:'2004',text:'Red Bull buys the Jaguar Racing team and enters Formula 1 as Red Bull Racing in 2005.'},
 {year:'2009',text:'First Grand Prix victory, Sebastian Vettel in China.'},
 {year:'2010–2013',text:'Four consecutive drivers’ and constructors’ championships with Vettel, with Adrian Newey as chief technical designer.'},
 {year:'2016',text:'Verstappen is promoted from Toro Rosso, the sister team, and wins on his Red Bull debut in Spain.'},
 {year:'2021',text:'Verstappen wins his first drivers’ title after a season-long fight with Mercedes.'},
 {year:'2022–2023',text:'Constructors’ titles in both seasons, with 2023 delivering 21 wins from 22 races for the team.'}
];
export const eras=[
 {name:'Hybrid era',years:'2014–2021',text:'Mercedes dominated early with Hamilton, a driver who also reached seven titles. Verstappen broke the sequence in 2021.'},
 {name:'Ground-effect era',years:'2022–2025',text:'A major technical reset. Red Bull won both 2022 and 2023 constructors’ titles, and McLaren won the 2024 constructors’ title.'},
 {name:'New regulations',years:'2026 onward',text:'Revised chassis rules and new power units, including Red Bull’s own powertrain division in partnership with Ford.'}
];
export const glossary=[
 ['Apex','The innermost point of a corner, where a driver aims to clip the kerb.'],
 ['Undercut','Pitting before a rival so fresh tyres gain enough time to jump them when they stop.'],
 ['Overcut','Staying out longer when the rival’s fresh tyres cannot make up the gap.'],
 ['Dirty air','Turbulent air behind another car that reduces downforce and tyre life.'],
 ['Porpoising','Bouncing at high speed on ground-effect cars as downforce stalls and recovers.'],
 ['Parc fermé','Rules limiting changes to a car between qualifying and the race.'],
 ['Delta','The time difference between two laps or two drivers.'],
 ['Lift and coast','Lifting off the throttle early to save fuel, tyres or temperature.'],
 ['Graining','Small rubber balls forming on the tyre surface, reducing grip.'],
 ['Box, box','The team radio call telling a driver to enter the pits.']
];
export const fanCulture={title:'The Orange Army',text:'Dutch fans travel in huge numbers, turning grandstands orange. Zandvoort’s Dutch Grand Prix returned in 2021 and Verstappen won it three years in a row from 2021 to 2023.'};
export const maxFacts=[
 {label:'Racing number',value:'33',detail:'His career number. He raced with 1 as champion from 2022 to 2024.'},
 {label:'Nationality',value:'Dutch',detail:'Born in Belgium, races under the Dutch flag.'},
 {label:'Team',value:'Red Bull',detail:'Promoted from Toro Rosso in 2016.'},
 {label:'Father',value:'Jos',detail:'Jos Verstappen raced in Formula 1 from 1994 to 2003.'}
];
