import 'dotenv/config';
import express from 'express';
import path from 'node:path';
import app from '../backend/src/app';
app.use(express.static('dist'));
app.get('/{*path}',(_req,res)=>res.sendFile(path.resolve('dist/index.html')));
app.listen(5173,'127.0.0.1',()=>console.log('Production build preview → http://localhost:5173'));
