import {ProviderSchema,type Race} from '../../../shared/data.js';
// Jolpica caps pages at 100 even when a larger limit is requested.
export async function fetchPages(url:string,request:(url:string)=>Promise<unknown>){
 const first=ProviderSchema.parse(await request(url));const d=first.MRData;
 const total=+d.total,limit=+d.limit;
 if(total<=limit)return first;
 if(limit<1||total>1200)throw new Error('Provider response exceeds bounded pagination');
 const pages=[];
 for(let offset=limit;offset<total;offset+=limit){const u=new URL(url);u.searchParams.set('offset',String(offset));pages.push(u.toString())}
 // At most two concurrent upstream calls after the first request.
 const all=[first];
 for(let i=0;i<pages.length;i+=2){const batch=await Promise.all(pages.slice(i,i+2).map(async u=>ProviderSchema.parse(await request(u))));all.push(...batch)}
 const races=new Map<string,Race>();
 for(const page of all){if(+page.MRData.total!==total)throw new Error('Provider changed during pagination');for(const race of page.MRData.RaceTable?.Races??[]){const old=races.get(race.round);if(!old)races.set(race.round,race);else{for(const field of ['Results','QualifyingResults','SprintResults'] as const){if(race[field]){if(field==='QualifyingResults')old[field]=[...(old[field]??[]),...race[field]!];else old[field]=[...(old[field]??[]),...race[field]!];}}}}}
 if(d.RaceTable)d.RaceTable.Races=[...races.values()];d.limit=d.total;d.offset='0';return first;
}
