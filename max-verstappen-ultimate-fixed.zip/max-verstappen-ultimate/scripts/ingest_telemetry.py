import fastf1,pathlib,json
root=pathlib.Path(__file__).resolve().parents[1]/'frontend/public/datasets'; cache=pathlib.Path('fastf1-cache');cache.mkdir(exist_ok=True);fastf1.Cache.enable_cache(str(cache))
s=fastf1.get_session(2023,1,'Q');s.load(telemetry=True,weather=False,messages=False)
manifest=[]
for driver in ['VER','LEC']:
 lap=s.laps.pick_drivers(driver).pick_fastest(); t=lap.get_car_data().add_distance();
 samples=[]
 for _,r in t.iterrows():
  samples.append({'time':round(r['Time'].total_seconds(),3),'distance':round(float(r['Distance']),2),'speed':int(r['Speed']),'throttle':int(r['Throttle']),'brake':bool(r['Brake']),'rpm':int(r['RPM']),'gear':int(r['nGear'])})
 name=f'bahrain-2023-Q-{driver}.json';(root/name).write_text(json.dumps(samples,separators=(',',':')))
 manifest.append({'id':driver,'driver':driver,'session':'Bahrain 2023 · Qualifying','lap':int(lap['LapNumber']),'lapTime':round(lap['LapTime'].total_seconds(),3),'sectors':[round(lap[f'Sector{i}Time'].total_seconds(),3) for i in [1,2,3]],'file':'/datasets/'+name,'source':'F1 timing via FastF1','sourceUrl':'https://docs.fastf1.dev/','channels':['speed','throttle','brake','rpm','gear'],'note':'Recorded car-data samples, resampled by upstream timing. Distance is integrated from speed by FastF1; not GPS geometry. Personal educational analysis; check F1 data rights before redistribution.'})
(root/'telemetry-manifest.json').write_text(json.dumps(manifest,indent=2))
print('saved',len(manifest),'laps')
