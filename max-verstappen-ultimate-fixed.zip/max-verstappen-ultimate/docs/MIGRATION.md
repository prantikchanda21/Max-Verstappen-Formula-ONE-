# Original functionality inventory and migration

The supplied archive was inspected before implementation. It contained nine static HTML pages, four CSS layers, imperative JavaScript, procedural Three.js geometry, and two Netlify functions. No licensed car GLB files, photos, or historical telemetry files were supplied.

| Original feature | Rebuilt location | Treatment |
|---|---|---|
| Overview, starting lights | `/` | Five lights retained; skip and replay added; session-aware intro |
| Counters / records / win curve | `/`, `/records` | Historical year labels; removed unsourced current totals |
| Career story | `/biography` | Expanded timeline through 2024; source link |
| Four procedural cars | `/garage` | RB16B, RB18, RB19, RB20 interpretations; engineering labels |
| Orbit / zoom / spin | `/garage` | OrbitControls; pointer/pinch; camera presets |
| Exploded view, hotspots | `/garage` | Retained component separation and numbered explanations |
| Screenshot / fullscreen | `/garage` | PNG capture, fullscreen; browser error messaging |
| Car comparisons | `/garage` | Driver-season wins, podiums and points comparison |
| Trophy sculpture / spin / reset | `/legacy` | Original abstract sculpture, selected season narrative |
| Austria / Miami / Monza paths | `/circuits` | Artistic maps, marker scrubbing, pause, annotations |
| Calendar / standings / results | `/race-center` | Paginated Jolpica, snapshots, qualifying and sprint tabs, constructors |
| Historical archive / driver comparison | `/career`, `/comparisons` | Search, season selection, paired result and qualifying comparisons |
| Recorded telemetry / replay | `/telemetry` | Bundled Bahrain 2023 Q laps; independent unit axes and distance alignment |
| Strategy inputs and chart | `/strategy` | Extended fuel, temperature, traffic, weather, SC/VSC and seeded uncertainty |
| AI helper | `/ai-engineer` | Groq only, server-retrieved context; deterministic failure mode |
| Mobile menu / scroll effects | All pages | Expanded navigation, responsive breakpoints, GSAP transitions |
| Old `.html` URLs | React redirects | Home, archive, tracks, engineer and original named routes retained |

## Corrected issues

- Removed all Netlify/OpenAI/OpenF1 runtime dependencies.
- Corrected 2021 championship points to **395.5**, rather than the original rounded 395.
- Removed hardcoded current career totals and unsourced 2025 graphs. Historical editorial content is explicitly scoped to 2024; recent data comes from the provider and timestamps.
- Added pagination: Jolpica's actual page cap is 100. A requested limit of 2000 cannot be treated as complete.
- Joined results across page boundaries by round before deriving statistics.
- Did not silently substitute a different season when a requested snapshot is absent.
- Accept unranked championship entries with absent numeric position instead of rejecting a whole standings response.
- Kept AI keys out of frontend environment variables and bundles.

## Deliberate constraints

No manufacturer-accurate models or photo assets were present; the procedural geometry is labeled conceptual. Circuit paths are artistic, without verified turn/DRS/elevation coordinates. Telemetry is a two-driver, one-session educational sample. No GPS reconstruction is implied. See DATA.md and TESTING.md for coverage and validation limits.
