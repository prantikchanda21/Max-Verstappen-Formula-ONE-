import {it,expect} from 'vitest';
import express from 'express';
import request from 'supertest';
import path from 'node:path';
import {readFileSync,existsSync} from 'node:fs';
import app from '../backend/src/app';
import config from '../vercel.json';
it.skipIf(!existsSync('dist/index.html'))('routes APIs before the SPA and serves the built shell on deep links',async()=>{
 expect(config.rewrites[0]).toEqual({source:'/api/:path*',destination:'/api'});
 const spaPattern=new RegExp('^'+config.rewrites[1].source+'$');
 expect(spaPattern.test('/api/results')).toBe(false);expect(spaPattern.test('/garage')).toBe(true);expect(spaPattern.test('/assets/app.js')).toBe(false);expect(spaPattern.test('/images/max/manifest.json')).toBe(false);
 if(!existsSync('dist/index.html'))throw Error('Run npm run build before the production-shell test');
 const server=express();server.use(app);server.use(express.static('dist'));server.get('/{*path}',(_req,res)=>res.sendFile(path.resolve('dist/index.html')));
 for(const url of ['/','/biography','/f1-101','/garage','/legacy','/race-center','/telemetry','/circuits','/strategy','/career','/comparisons','/records','/ai-engineer']){const r=await request(server).get(url);expect(r.status).toBe(200);expect(r.text).toContain('<div id="root">')}
 expect((await request(server).get('/api/missing')).headers['content-type']).toContain('json');
 const html=readFileSync('dist/index.html','utf8');for(const match of html.matchAll(/(?:src|href)="(\/assets\/[^\"]+)"/g))expect(existsSync('dist'+match[1])).toBe(true);
});
