# Data provenance and refresh

## Race data

`datasets/historical/snapshots.json` contains source URL, retrieval timestamp and original provider tables. Its complete pages are joined by race round. In merged tables, `MRData.limit` is replaced by the merged total and offset is set to zero; a pagination note identifies this transformation. It is a deployment snapshot, not a live data store.

Provider: https://api.jolpi.ca/ergast/f1/
Documentation: https://api.jolpi.ca/docs/
Source project and licensing: https://github.com/jolpica/jolpica-f1

Coverage: race results and driver standings for 2015–2026; calendars, constructor standings, qualifying and sprint for 2021–2026. The 2026 snapshot is incomplete **as a season**, covering only the records returned on retrieval. An empty sprint table means no published sprint records, not a provider error. Qualifying coverage before 2021 is online-only unless you ingest those seasons.

Jolpica is community-maintained and not an official live timing service. Historical or recent changes can be delayed or corrected. The displayed timestamp records retrieval, not when the source last corrected a result.

Request flow: warm instance cache → Jolpica with bounded pagination → stale verified warm response → same-season bundled snapshot → explicit 503. Requests for the same table are deduplicated within an instance. CDN headers add shared caching. Neither memory cache nor rate limiting is durable across function instances. There is no background refresh process or database.

### Update after a Grand Prix

```sh
npm run data:update -- 2026
npm test
npm run build
```

Review changed source counts and timestamps, commit, and redeploy. Ingestion writes only during development/build preparation. Production functions never modify snapshot files. If ingestion fails, the previous snapshot is retained because the script writes after collecting all requested tables.

## Recorded telemetry

The static `frontend/public/datasets` directory contains fastest qualifying laps from **Bahrain 2023**, Verstappen (VER) and Leclerc (LEC), prepared with FastF1 from F1 timing data. The manifest gives lap, sector times, source and measurement notes.

- Speed: km/h; throttle: percent; brake: boolean; RPM: revolutions/minute; gear: integer.
- Time is relative to the selected lap's car-data slice; endpoint samples may extend slightly around the timed lap.
- Distance is numerical integration of recorded speed performed by FastF1, not GPS position.
- Rival delta uses linear time interpolation at equal integrated distance; it is approximate, not an official sector/timing delta.
- Playback moves one sample every 200 ms; it is sample playback, not exact wall-clock race reconstruction.
- Track positions, steering angle, high-frequency GPS, live timing and tyre temperatures are unavailable and not synthesized.
- Data traces are factual timing data; FastF1's software license does not grant ownership of underlying F1 data. No broad data redistribution license is asserted. Review applicable source terms before public/commercial redistribution.

FastF1: https://github.com/theOehrly/Fast-F1
Documentation: https://docs.fastf1.dev/

The reproducible optional importer is `scripts/ingest_telemetry.py`. Install FastF1 separately (`python -m pip install fastf1`) only when updating telemetry. Python is not a website/runtime dependency. Do not commit its download cache.

## Editorial and art

The biography and records describe the 2015–2024 archive, not current career totals. Sources:
- Formula 1's Max Verstappen Hall of Fame profile: https://www.formula1.com/en/information/drivers-hall-of-fame-max-verstappen.2DttvntAuFvHYrBY2tV8fN
- 2024 title report: https://www.formula1.com/en/latest/article/a-very-special-and-beautiful-season-verstappen-proud-after-joining-elites-as.4Q2zWcWyFVwbFgxdKJlOk8
- Circuit guides linked on the circuit page (2024 configurations).

No third-party car meshes, photographs, logos, or video files are included. The car, trophy, schematic paths and favicon are original programmatic interpretations. Names and historical references do not imply endorsement. Barlow fonts are distributed through Fontsource under their included OFL license.

## Statistical definitions

Archive points sum Grand Prix results. They exclude sprint points and championship adjustments; the standings endpoint is authoritative for championship points. “Entries” count provider result entries, not a guaranteed start. Head-to-head compares classified positions, includes retirements and excludes races without both drivers. Win and podium rates use recorded entries as denominator. No claim that this isolates driver skill from machinery is made.

## Simulation

Strategy uses declared compound offsets, tyre-age degradation, linear fuel effect, temperature penalty, weather pace offsets, traffic and pit-loss assumptions. SC/VSC affect a bounded lap window. Monte Carlo varies a race-wide pace offset with a deterministic seeded generator. Its interval represents this model's assumptions, not calibrated predictive confidence. Wet tyre selection, race legality, overtaking and finishing positions are not modeled.
