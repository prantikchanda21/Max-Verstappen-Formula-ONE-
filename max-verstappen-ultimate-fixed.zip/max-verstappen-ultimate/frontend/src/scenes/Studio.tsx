import {Suspense,useEffect,useMemo,useRef,useState} from 'react';
import {Canvas,useFrame,useThree} from '@react-three/fiber';
import {OrbitControls,Html,Line,ContactShadows,useGLTF} from '@react-three/drei';
import * as THREE from 'three';
import {useSettings} from '../stores/settings';
import {Boundary} from '../components/UI';
export interface StudioProps {car?:string;explode?:boolean;wireframe?:boolean;spin?:boolean;airflow?:boolean;hotspots?:boolean;preset?:string;trophy?:boolean;onPart?:(part:string)=>void}
const facts:Record<string,string>={'Front wing':'The front wing generates downforce and conditions airflow around the front tyres. Geometry here is conceptual.','Halo':'The titanium halo protects the cockpit. Introduced in Formula 1 in 2018.','Sidepod':'Sidepods house cooling systems and shape the air reaching the floor and rear of the car.','Rear wing':'The rear wing generates downforce. DRS reduces drag by opening an adjustable flap under permitted conditions.'};
function Box({position,scale,color='#152d52',wireframe=false,rotation=[0,0,0]}:{position:[number,number,number];scale:[number,number,number];color?:string;wireframe?:boolean;rotation?:[number,number,number]}){return <mesh position={position} scale={scale} rotation={rotation} castShadow><boxGeometry/><meshPhysicalMaterial color={color} metalness={.65} roughness={.3} clearcoat={1} wireframe={wireframe}/></mesh>}
function Car({car='RB19',explode=false,wireframe=false,spin=false,airflow=false,hotspots=false,onPart}:StudioProps){
 const group=useRef<THREE.Group>(null),wheels=useRef<THREE.Group[]>([]),motion=useSettings(s=>s.motion),e=explode?1:0;
 const color=car==='RB16B'?'#203665':car==='RB20'?'#174d78':'#152b50';
 const profile=useMemo(()=>new THREE.SplineCurve([[.01,-2.6],[.17,-2.0],[.26,-.8],[.3,.2],[.21,1.4],[.09,2.55],[.01,3]].map(([x,y])=>new THREE.Vector2(x,y))).getPoints(60),[]);
 useFrame((_,dt)=>{if(group.current&&spin&&motion)group.current.rotation.y+=dt*.16;if(spin&&motion)wheels.current.forEach(w=>{if(w)w.rotation.z-=dt*2})});
 const paint=<meshPhysicalMaterial color={color} metalness={.6} roughness={.26} clearcoat={1} wireframe={wireframe}/>;
 return <group ref={group} position={[0,.05,0]}>
  <mesh rotation={[0,0,-Math.PI/2]} position={[0,.55+e*.45,0]} scale={[1,.88,1]} castShadow><latheGeometry args={[profile,40]}/>{paint}</mesh>
  <Box position={[-.3,.16,0]} scale={[4.4,.07,1.65]} color="#10141c" wireframe={wireframe}/>
  <mesh position={[.2,.76+e*.5,0]} scale={[.55,.1,.23]}><sphereGeometry args={[1,24,16]}/><meshStandardMaterial color="#030509" wireframe={wireframe}/></mesh>
  <mesh position={[.12,.91+e*.5,0]}><sphereGeometry args={[.14,24,16]}/><meshStandardMaterial color="#ed4635" wireframe={wireframe}/></mesh>
  <mesh position={[-.35,.88+e*.5,0]} scale={[.38,.26,.22]}><sphereGeometry args={[1,24,16]}/>{paint}</mesh>
  {[-1,1].map(q=><group key={q}>
   <mesh position={[-.6,.4+e*.3,q*(.5+e*.5)]} scale={[1.5,car==='RB16B'?.28:.22,.32]} castShadow><sphereGeometry args={[1,32,20]}/>{paint}</mesh>
   <Box position={[-.65,.6+e*.3,q*(.51+e*.5)]} scale={[1.6,.035,.17]} color="#f2c844" wireframe={wireframe}/>
   <Line points={[[.8,.72+e*.5,0],[.62,1.06+e*.5,q*.14],[-.2,1.04+e*.5,q*.28],[-.45,.75+e*.5,q*.27]]} color="#8090a3" lineWidth={4}/>
   {[1.7,-1.8].map((x,k)=><group key={x} position={[x*(1+e*.15),.44,q*(.92+e*.7)]}>
    <group ref={n=>{if(n)wheels.current[(q===1?2:0)+k]=n}}>
     <mesh rotation={[Math.PI/2,0,0]} castShadow><cylinderGeometry args={[.43,.43,k?.46:.36,48]}/><meshStandardMaterial color="#121317" roughness={.92} wireframe={wireframe}/></mesh>
     <mesh position={[0,0,q*(k?.24:.19)]} rotation={[q<0?Math.PI:0,0,0]}><circleGeometry args={[.27,40]}/><meshStandardMaterial color="#27303a" metalness={.8} roughness={.25} wireframe={wireframe}/></mesh>
     <mesh position={[0,0,q*(k?.244:.194)]}><torusGeometry args={[.35,.012,8,48]}/><meshStandardMaterial color="#e7cc3c"/></mesh>
     {[0,1,2,3,4].map(i=><Box key={i} position={[Math.cos(i*1.257)*.12,Math.sin(i*1.257)*.12,q*(k?.25:.2)]} scale={[.24,.026,.024]} rotation={[0,0,i*1.257]} color="#9ba6b0" wireframe={wireframe}/>)}
    </group>
   </group>)}
   {[1.7,-1.8].map(x=><group key={x}>{[.26,-.26].map(dx=><Line key={dx} points={[[x+dx,.38,q*.2],[x,.44,q*(.8+e*.7)]]} color="#677587" lineWidth={2}/>)}</group>)}
  </group>)}
  <group position={[2.68+e*.65,.1,0]}>{[0,1,2].map(i=><Box key={i} position={[-i*.14,i*.1,0]} scale={[.4,.035,1.95-i*.07]} rotation={[0,0,-.15]} color={i===1?color:'#141921'} wireframe={wireframe}/>)}{[-1,1].map(q=><Box key={q} position={[-.1,.15,q]} scale={[.68,.3,.025]} color={color} wireframe={wireframe}/>)}</group>
  <group position={[-2.45-e*.6,e*.9,0]}><Box position={[0,.65,0]} scale={[.1,.85,.08]} color="#141921" wireframe={wireframe}/><Box position={[0,1.12,0]} scale={[.62,.045,1.2]} rotation={[0,0,-.18]} wireframe={wireframe}/><Box position={[-.1,1.27,0]} scale={[.4,.045,1.2]} rotation={[0,0,-.3]} color="#ef4435" wireframe={wireframe}/>{[-1,1].map(q=><Box key={q} position={[-.04,1.08,q*.61]} scale={[.85,.48,.035]} wireframe={wireframe}/>)}</group>
  {airflow&&Array.from({length:7},(_,i)=><Line key={i} points={Array.from({length:45},(_,j)=>{const x=4-j*.19;return [x,1.1+Math.sin(j/9)*.22+(i%3)*.16,(i-3)*.35] as [number,number,number]})} color="#79b8e7" transparent opacity={.5} lineWidth={1}/>)}
  {hotspots&&!explode&&Object.keys(facts).map((name,i)=><Html key={name} position={([[2.6,.6,0],[.3,1.35,0],[-.5,.8,.8],[-2.4,1.65,0]] as [number,number,number][])[i]} center><button className="hotspot" title={name} aria-label={name} onClick={()=>onPart?.(facts[name])}>{i+1}</button></Html>)}
 </group>
}
const TROPHY_URL='/models/trophy.glb';
function GlbTrophy(){const {scene}=useGLTF(TROPHY_URL);const model=useMemo(()=>{const m=scene.clone(true);m.traverse(o=>{const mesh=o as THREE.Mesh;if(mesh.isMesh){mesh.castShadow=true;mesh.receiveShadow=true}});const box=new THREE.Box3().setFromObject(m),size=box.getSize(new THREE.Vector3()),center=box.getCenter(new THREE.Vector3()),k=3.3/(size.y||1);m.scale.setScalar(k);m.position.set(-center.x*k,.1-box.min.y*k,-center.z*k);return m},[scene]);return <primitive object={model}/>}
function ProceduralTrophy(){return <group position={[0,1.6,0]}><mesh position={[0,-1.5,0]}><cylinderGeometry args={[1,1.12,.24,64]}/><meshStandardMaterial color="#0e1b2a" metalness={.8} roughness={.25}/></mesh><mesh><cylinderGeometry args={[.22,.38,2.7,48]}/><meshStandardMaterial color="#b8c2d0" metalness={.9} roughness={.22}/></mesh><mesh position={[0,1.35,0]}><sphereGeometry args={[.42,32,24]}/><meshStandardMaterial color="#d7bb70" metalness={.8} roughness={.2}/></mesh>{[0,1,2,3].map(i=><mesh key={i} position={[0,-.9+i*.55,0]} rotation={[Math.PI/2+.15*i,.18*i,0]}><torusGeometry args={[.7+i*.16,.055,12,80]}/><meshStandardMaterial color={i%2?'#d7bb70':'#ef493c'} metalness={.7} roughness={.25}/></mesh>)}</group>}
function Trophy({spin}:StudioProps){const g=useRef<THREE.Group>(null);const motion=useSettings(s=>s.motion);const [hasModel,setHasModel]=useState(false);
 useEffect(()=>{let live=true;fetch(TROPHY_URL,{method:'HEAD'}).then(r=>{const t=r.headers.get('content-type')||'';if(live&&r.ok&&!t.includes('text/html'))setHasModel(true)}).catch(()=>{});return()=>{live=false}},[]);
 useFrame((_,dt)=>{if(g.current&&spin&&motion)g.current.rotation.y+=dt*.25});
 return <group ref={g}>{hasModel?<Suspense fallback={<ProceduralTrophy/>}><GlbTrophy/></Suspense>:<ProceduralTrophy/>}</group>}
function Camera({preset='hero',trophy}:{preset?:string;trophy?:boolean}){const {camera,invalidate}=useThree();useEffect(()=>{const p:Record<string,[number,number,number]>={hero:[7,4.5,7],side:[0,2,10],front:[10,2,0],top:[0,10,.01]};const target:[number,number,number]=trophy?[5,3.5,6]:(p[preset]??p.hero);camera.position.set(...target);camera.lookAt(0,trophy?1.5:.4,0);invalidate()},[preset,trophy,camera,invalidate]);return null}
export default function Studio(props:StudioProps){
 const ref=useRef<HTMLDivElement>(null),[visible,setVisible]=useState(true),[lost,setLost]=useState(false),quality=useSettings(s=>s.quality),motion=useSettings(s=>s.motion);
 useEffect(()=>{const observer=new IntersectionObserver(([e])=>setVisible(e.isIntersecting&&!document.hidden));if(ref.current)observer.observe(ref.current);const visibility=()=>setVisible(!document.hidden);document.addEventListener('visibilitychange',visibility);return()=>{observer.disconnect();document.removeEventListener('visibilitychange',visibility)}},[]);
 const fallback=<div className="scene-fallback"><strong>{props.trophy?'CHAMPIONSHIP COLLECTION':props.car??'RB19'}</strong><p>3D is unavailable on this device. Engineering details and all data pages remain accessible.</p></div>;
 return <div className="studio" ref={ref}><Boundary fallback={fallback}>{lost?fallback:<Canvas camera={{position:[7,4.5,7],fov:36}} dpr={quality==='high'?[1,1.7]:1} frameloop={visible&&motion&&props.spin?'always':'demand'} gl={{antialias:quality==='high',preserveDrawingBuffer:true}} onCreated={({gl})=>{gl.domElement.addEventListener('webglcontextlost',()=>setLost(true));gl.setClearColor('#080d17',0)}} fallback={fallback}>
 <Camera preset={props.preset} trophy={props.trophy}/><ambientLight intensity={1.2}/><hemisphereLight args={['#c9d9ff','#08090c',1.7]}/><directionalLight position={[4,8,5]} intensity={4}/><directionalLight position={[-5,3,-2]} color="#ee4940" intensity={3}/><pointLight position={[-3,4,6]} color="#8ebfff" intensity={35}/>
 {props.trophy?<Trophy {...props}/>:<Car {...props}/>}
 <mesh rotation={[-Math.PI/2,0,0]} position={[0,-.01,0]}><ringGeometry args={[3.7,3.72,100]}/><meshBasicMaterial color="#ef463a" transparent opacity={.5}/></mesh>
 {quality==='high'&&<ContactShadows position={[0,-.005,0]} opacity={.6} scale={15} blur={2.5} far={4} resolution={256} frames={1}/>}
 <OrbitControls makeDefault target={[0,props.trophy?1.5:.45,0]} minDistance={4} maxDistance={16} maxPolarAngle={Math.PI/2-.03} enablePan={false}/>
 </Canvas>}</Boundary></div>
}
