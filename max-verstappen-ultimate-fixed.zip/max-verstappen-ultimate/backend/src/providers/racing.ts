import {ProviderSchema,type DataEnvelope,type Kind} from '../../../shared/data.js';
import {fetchPages} from './pagination.js';
import snapshots from '../../../datasets/historical/snapshots.json' with {type:'json'};
type Snapshot={url:string;retrievedAt:string;payload:unknown};
const bundled:Record<string,Snapshot>=snapshots;
const cache=new Map<string,{value:DataEnvelope;expires:number}>();
const inflight=new Map<string,Promise<DataEnvelope>>();
const endpoint:Record<Kind,string>={calendar:'races',results:'results',standings:'driverStandings',constructors:'constructorStandings',qualifying:'qualifying',sprint:'sprint'};
function normalize(payload:unknown,season:number,kind:Kind,source:DataEnvelope['source'],updatedAt:string,sourceUrl:string):DataEnvelope{
 const d=ProviderSchema.parse(payload).MRData;
 if(!d.RaceTable&&!d.StandingsTable)throw new Error('Missing provider table');
 return {season,kind,races:d.RaceTable?.Races??[],standings:d.StandingsTable?.StandingsLists.at(-1)?.[kind==='constructors'?'ConstructorStandings':'DriverStandings']??[],source,updatedAt,sourceUrl,partial:Number(d.total)>Number(d.limit)+Number(d.offset)};
}
async function request(url:string,deadline:number):Promise<unknown>{
 for(let attempt=0;attempt<2;attempt++){
  const remaining=deadline-Date.now();if(remaining<=0)throw new Error('Provider request budget exceeded');
  const response=await fetch(url,{signal:AbortSignal.timeout(Math.min(3500,remaining)),headers:{Accept:'application/json'}});
  if(response.status===429)throw new Error('Provider rate limit');
  if(response.ok)return response.json();
  if(response.status<500||attempt===1)throw new Error(`Provider HTTP ${response.status}`);
 }
 throw new Error('Provider unavailable');
}
export async function racing(season:number,kind:Kind):Promise<DataEnvelope>{
 const key=`${season}/${kind}`,now=Date.now(),old=cache.get(key);
 if(old&&old.expires>now)return old.value;
 if(inflight.has(key))return inflight.get(key)!;
 const work=(async()=>{
  try{
   if(process.env.DATA_OFFLINE==='true')throw new Error('Offline verification');
   const base=(process.env.JOLPICA_BASE_URL||'https://api.jolpi.ca/ergast/f1').replace(/\/$/,'');
   const url=`${base}/${season}/${endpoint[kind]}.json?limit=100`;
   const deadline=Date.now()+9500;
   const value=normalize(await fetchPages(url,u=>request(u,deadline)),season,kind,'jolpica',new Date().toISOString(),url);
   if(cache.size>100)cache.delete(cache.keys().next().value!);
   const ttl=Math.min(86400,Math.max(30,Number(process.env.CACHE_TTL_SECONDS)||3600));
   cache.set(key,{value,expires:now+ttl*1000});return value;
  }catch{
   if(old)return {...old.value,source:'stale-cache' as const,warning:'Provider unavailable; showing the last verified response from this function instance.'};
   const snap=bundled[key];
   if(process.env.DATA_FALLBACK_ENABLED!=='false'&&snap)return {...normalize(snap.payload,season,kind,'bundled',snap.retrievedAt,snap.url),warning:'Bundled historical snapshot. It does not update until redeployment.'};
   throw Object.assign(new Error('No verified data is available for this season. Try 2021–2024 or retry later.'),{status:503});
  }
 })();inflight.set(key,work);
 try{return await work}finally{inflight.delete(key)}
}
export function clearCache(){cache.clear();inflight.clear()}
