@echo off
setlocal
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo ERROR: Node.js is missing. Install Node.js 22 LTS or newer from nodejs.org.
  pause
  exit /b 1
)
where npm >nul 2>nul
if errorlevel 1 (
  echo ERROR: npm was not found. Reinstall Node.js with npm enabled.
  pause
  exit /b 1
)
node -e "if(Number(process.versions.node.split('.')[0])<22)process.exit(1)"
if errorlevel 1 (
  echo ERROR: Node.js 22 or newer is required.
  pause
  exit /b 1
)
if not exist node_modules\vite\package.json (
  echo Installing locked dependencies...
  call npm ci
  if errorlevel 1 (
    echo ERROR: Installation failed. Check internet access and rerun this file.
    pause
    exit /b 1
  )
)
if not exist .env copy .env.example .env >nul
call npm run typecheck
if errorlevel 1 (
  echo ERROR: Configuration or TypeScript validation failed.
  pause
  exit /b 1
)
echo Starting frontend and Express API at http://localhost:5173
echo Groq is optional. Add GROQ_API_KEY to .env for AI responses.
echo Keep this window open. Press Ctrl+C to stop both frontend and API.
start "Open website" /b powershell -NoProfile -Command "$u='http://localhost:5173/api/health'; for($i=0;$i -lt 60;$i++){try{$r=Invoke-WebRequest -UseBasicParsing $u -TimeoutSec 1;if($r.StatusCode -eq 200){Start-Process 'http://localhost:5173';exit}}catch{};Start-Sleep -Seconds 1}"
call npm run dev
if errorlevel 1 (
  echo ERROR: Server stopped unexpectedly. Check whether port 5173 is in use.
  pause
)
endlocal
