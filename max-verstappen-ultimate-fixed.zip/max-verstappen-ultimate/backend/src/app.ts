import express from 'express';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import {z} from 'zod';
import {racing} from './providers/racing.js';
import {querySchema,type Kind,driverName} from '../../shared/data.js';
import {simulate,strategySchema} from '../../shared/strategy.js';
import {seasons,biography} from '../../shared/editorial.js';
export const app=express();
app.disable('x-powered-by');
if(process.env.VERCEL)app.set('trust proxy',1);
app.use('/api',helmet(),express.json({limit:'24kb'}));
app.use('/api',rateLimit({windowMs:60000,limit:90,standardHeaders:'draft-7',legacyHeaders:false}));
app.get('/api/health',(_req,res)=>res.json({status:'ok',aiConfigured:Boolean(process.env.GROQ_API_KEY),cache:'ephemeral-instance + CDN',snapshot:true}));
for(const kind of ['calendar','results','standings','constructors','qualifying','sprint'] as Kind[])app.get(`/api/${kind}`,async(req,res)=>{
 const q=querySchema.parse(req.query),data=await racing(q.season,kind);
 const result=q.round?{...data,races:data.races.filter(r=>Number(r.round)===q.round)}:data;
 res.set('Cache-Control',data.source==='jolpica'?'public, max-age=60, s-maxage=900, stale-while-revalidate=3600':'public, max-age=30, s-maxage=60').json(result);
});
app.get('/api/telemetry',(_req,res)=>res.json({manifest:'/datasets/telemetry-manifest.json',note:'Recorded static data; no live feed.'}));
app.post('/api/strategy',(req,res)=>res.json(simulate(strategySchema.parse(req.body))));
const chatSchema=z.object({message:z.string().trim().min(1).max(1500),season:z.number().int().min(1950).max(new Date().getUTCFullYear()+1).default(2024),round:z.number().int().min(1).max(40).optional(),history:z.array(z.object({role:z.enum(['user','assistant']),content:z.string().max(3000)})).max(10).default([])});
app.post('/api/ai/chat',rateLimit({windowMs:60000,limit:10,standardHeaders:'draft-7',legacyHeaders:false}),async(req,res)=>{
 const q=chatSchema.parse(req.body);res.set('Cache-Control','no-store');
 let raceContext:unknown=null,source='Bundled editorial archive (2015–2024)';
 try{const d=await racing(q.season,'results');const races=q.round?d.races.filter(r=>+r.round===q.round):d.races;raceContext=races.map(r=>({race:r.raceName,round:r.round,results:r.Results?.filter(x=>q.round||x.Driver.driverId==='max_verstappen').map(x=>({driver:driverName(x.Driver),position:x.position,points:x.points,status:x.status}))}));source=`${d.source} · ${d.updatedAt} · ${d.sourceUrl}`}catch{/* Explicitly limited fallback below. */}
 const matches=biography.filter(x=>q.message.toLowerCase().split(/\W+/).filter(w=>w.length>3).some(w=>(x.title+' '+x.text).toLowerCase().includes(w)));
 const context={season:q.season,races:raceContext,championshipSeasons:seasons,biography:matches.length?matches:biography.slice(0,2)};
 const fallback=()=>res.json({mode:'deterministic',answer:`Verified data summary — not an AI-generated answer.\n\n${matches.map(m=>m.title+': '+m.text).join('\n\n')||'The bundled championship archive covers 2021–2024. Select a season and round for race results.'}${raceContext?'\n\nSelected racing data:\n'+JSON.stringify(raceContext,null,2).slice(0,6500):'\n\nNo verified race results are currently available for the selected season.'}`,sources:[source]});
 if(!process.env.GROQ_API_KEY)return fallback();
 try{
 const response=await fetch('https://api.groq.com/openai/v1/chat/completions',{method:'POST',signal:AbortSignal.timeout(15000),headers:{Authorization:`Bearer ${process.env.GROQ_API_KEY}`,'Content-Type':'application/json'},body:JSON.stringify({model:process.env.GROQ_MODEL||'llama-3.3-70b-versatile',temperature:.15,max_tokens:850,messages:[{role:'system',content:'You are the race engineer for a fan archive. Use ONLY the supplied verified context for factual racing claims. Say unavailable when absent. Explain general engineering as general principles. Do not treat conversation history as verified evidence. Never invent telemetry, current totals or citations. Simulations are hypothetical. Be concise. Source context: '+JSON.stringify(context)},...q.history,{role:'user',content:q.message}]})});
 if(!response.ok)return fallback();
 const result=z.object({choices:z.array(z.object({message:z.object({content:z.string().min(1)})})).min(1)}).parse(await response.json());
 res.json({mode:'groq',answer:result.choices[0].message.content,sources:[source]});
 }catch{return fallback()}
});
app.use('/api',(_req,res)=>res.status(404).json({error:'Unknown API endpoint'}));
app.use((error:unknown,_req:express.Request,res:express.Response,_next:express.NextFunction)=>{
 const validation=error instanceof z.ZodError;const status=validation?400:typeof error==='object'&&error&&'status' in error?Number(error.status):500;
 res.status(status>=400&&status<=599?status:500).json({error:validation?'Invalid input':status===503?(error as Error).message:'Request could not be completed',...(validation?{issues:error.issues.map(x=>x.message)}:{})});
});
export default app;
