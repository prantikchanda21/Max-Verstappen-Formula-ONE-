Drop your trophy model here as trophy.glb
