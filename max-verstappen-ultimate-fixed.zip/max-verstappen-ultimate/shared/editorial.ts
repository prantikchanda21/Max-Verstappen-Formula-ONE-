export const seasons=[
 {year:2021,car:'RB16B',wins:10,podiums:18,points:395.5,title:'The breakthrough',text:'A season-long contest with Lewis Hamilton ended with Verstappen’s first title in Abu Dhabi. The controversial final-lap restart remains part of the story.'},
 {year:2022,car:'RB18',wins:15,podiums:17,points:454,title:'A new era',text:'Ground-effect regulations reshaped the field. Recovery from early retirements became a dominant title campaign, sealed in Japan.'},
 {year:2023,car:'RB19',wins:19,podiums:21,points:575,title:'Beyond the benchmark',text:'Nineteen victories in 22 Grands Prix. Ten consecutive wins from Miami to Monza. A season defined by relentless execution.'},
 {year:2024,car:'RB20',wins:9,podiums:14,points:437,title:'Under pressure',text:'As the field closed in, consistency mattered. A recovery from 17th on the grid to victory in São Paulo preceded a fourth title, secured in Las Vegas.'}
];
export const biography=[
 {year:'1997',title:'Born into motorsport',text:'Born on 30 September 1997 in Hasselt, Belgium, Max grew up in a racing family. His father Jos raced in Formula 1; his mother Sophie Kumpen competed in karting.'},
 {year:'2005–2013',title:'The karting foundations',text:'Years of karting developed precision, racecraft and mechanical understanding. In 2013 he won the World KZ karting championship before moving into cars.'},
 {year:'2014',title:'Straight into contention',text:'His European Formula 3 campaign produced ten victories and third in the championship. Red Bull’s junior programme led to a Toro Rosso Formula 1 seat for 2015.'},
 {year:'2015',title:'Seventeen. And on the grid.',text:'The Australian Grand Prix marked his Formula 1 debut with Toro Rosso at 17 years and 166 days, making him the youngest driver to start a Grand Prix.'},
 {year:'2016',title:'A first race that changed everything',text:'Promoted to Red Bull Racing before the Spanish Grand Prix, he won on debut for the team. At 18 years and 228 days, he became the youngest Grand Prix winner.'},
 {year:'2016–2020',title:'Learning at the limit',text:'Victories and podiums built experience against established champions. His recovery to third in the rain at the 2016 Brazilian Grand Prix became a defining wet-weather drive.'},
 ...seasons.map(s=>({year:String(s.year),title:s.title,text:s.text})),
 {year:'Technique',title:'Rotation, confidence, commitment',text:'Verstappen is associated with a responsive front end and an ability to manage an unstable rear. Braking, rotation and throttle application vary with the car and circuit; these are qualitative observations, not telemetry measurements.'},
 {year:'Rivalries',title:'Competition shapes the story',text:'Hamilton defined the 2021 title fight. Leclerc was a key early rival in 2022, while Norris challenged in 2024. Cross-season comparisons need the context of cars, regulations and scoring systems.'}
];
export const editorialSource='https://www.formula1.com/en/information/drivers-hall-of-fame-max-verstappen.2DttvntAuFvHYrBY2tV8fN';
export const records=[{value:'19',label:'Wins in one season',detail:'19 of 22 Grands Prix · 2023'},{value:'10',label:'Consecutive victories',detail:'Miami → Monza · 2023'},{value:'575',label:'Points in one season',detail:'2023 scoring system'},{value:'1,003',label:'Laps led in one season',detail:'2023 campaign'},{value:'18y 228d',label:'Youngest race winner',detail:'Spanish Grand Prix · 2016'},{value:'17y 166d',label:'Youngest race starter',detail:'Australian Grand Prix · 2015'}];
