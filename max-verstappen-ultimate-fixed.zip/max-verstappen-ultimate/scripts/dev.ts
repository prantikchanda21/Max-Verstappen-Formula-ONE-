import 'dotenv/config';
import express from 'express';
import {createServer} from 'vite';
import app from '../backend/src/app';
const vite=await createServer({server:{middlewareMode:true}});
app.use(vite.middlewares as express.RequestHandler);
const server=app.listen(5173,'127.0.0.1',()=>console.log('The Verstappen File → http://localhost:5173 (frontend + API)'));
for(const signal of ['SIGINT','SIGTERM'])process.on(signal,()=>{server.close();void vite.close().then(()=>process.exit(0))});
