import {defineConfig} from 'vite';
import react from '@vitejs/plugin-react';
import tailwind from '@tailwindcss/vite';
export default defineConfig({root:'frontend',plugins:[react(),tailwind()],build:{outDir:'../dist',emptyOutDir:true,chunkSizeWarningLimit:1100},server:{host:'127.0.0.1',port:5173}});
