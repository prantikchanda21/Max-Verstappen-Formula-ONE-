import {useEffect,useState} from 'react';
export type PhotoEntry={file:string;title:string;credit?:string;license?:string;licenseUrl?:string;source?:string;slots?:string[];position?:string};
type Manifest={photos:PhotoEntry[]};
let cache:Promise<PhotoEntry[]>|null=null;
function load(){if(!cache)cache=fetch('/images/max/manifest.json').then(r=>r.ok?r.json() as Promise<Manifest>:{photos:[]}).then(m=>Array.isArray(m.photos)?m.photos:[]).catch(()=>[]);return cache}
export function usePhotos(){const [photos,setPhotos]=useState<PhotoEntry[]>([]);useEffect(()=>{let live=true;void load().then(p=>{if(live)setPhotos(p)});return()=>{live=false}},[]);return photos}
function score(p:PhotoEntry,keywords:string[]){const hay=p.title.toLowerCase();return keywords.reduce((n,k)=>n+(hay.includes(k.toLowerCase())?1:0),0)}
export function pick(photos:PhotoEntry[],slot:string,keywords:string[]=[],offset=0){if(!photos.length)return undefined;const exact=photos.find(p=>p.slots?.includes(slot));if(exact)return exact;const ranked=photos.map((p,i)=>({p,i,s:score(p,keywords)})).sort((a,b)=>b.s-a.s||a.i-b.i);if(ranked[0].s>0)return ranked[0].p;return photos[offset%photos.length]}
export default function Photo({slot,keywords,offset=0,label,className='',tall}:{slot:string;keywords?:string[];offset?:number;label:string;className?:string;tall?:boolean}){
 const photos=usePhotos(),entry=pick(photos,slot,keywords,offset),[broken,setBroken]=useState(false);
 useEffect(()=>setBroken(false),[entry?.file]);
 const ok=entry&&!broken;
 return <figure className={`photo ${tall?'tall':''} ${className}`}>{ok?<img style={entry.position?{objectPosition:entry.position}:undefined} src={`/images/max/${entry.file}`} alt={`Max Verstappen — ${label}`} loading="lazy" decoding="async" onError={()=>setBroken(true)}/>:<div className="photo-fallback" role="img" aria-label={`Photo placeholder: ${label}`}><b>33</b><span>MAX VERSTAPPEN</span></div>}
  <figcaption><span>{label}</span>{ok&&entry.credit&&<small>{entry.source?<a href={entry.source} target="_blank" rel="noreferrer">{entry.credit}</a>:entry.credit}{entry.license&&` · ${entry.license}`}</small>}</figcaption></figure>
}
