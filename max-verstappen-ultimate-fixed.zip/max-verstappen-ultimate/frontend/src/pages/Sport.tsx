import {PageHeader} from '../components/UI';
import Photo from '../components/Photo';
import {weekend,points,tyres,tyreNote,flags,technology,redBull,eras,glossary,fanCulture,maxFacts} from '../../../shared/f1';
export default function Sport(){
 return <div className="page">
  <PageHeader index="03" title="Formula 1," accent="explained." description="The sport behind the driver. A short guide to race weekends, points, tyres, technology and the team that shaped Verstappen’s career."/>
  <div className="photo-band"><Photo slot="sport-1" keywords={['2023','2022','champion']} offset={0} label="On the grid" tall/><Photo slot="sport-2" keywords={['podium','celebration']} offset={1} label="Celebrating a win" tall/><Photo slot="sport-3" keywords={['car','rb19','rb18']} offset={2} label="In the car" tall/></div>
  <section className="panel"><div className="eyebrow">THE BASICS</div><h2>Twenty drivers. Ten teams. One championship.</h2><p>Formula 1 is a season of Grands Prix around the world. Each driver scores points in races, and the totals decide the Drivers’ Championship. Teams also add their two drivers’ points together for the Constructors’ Championship.</p></section>
  <h2 className="block-title">A race weekend</h2>
  <div className="step-grid">{weekend.map(w=><article className="step-card" key={w.step}><span className="eyebrow">{w.step}</span><h3>{w.title}</h3><p>{w.text}</p></article>)}</div>
  <div className="two-col"><section className="panel"><div className="eyebrow">SCORING</div><h2>Points system</h2><div className="points-row">{points.race.map((p,i)=><span key={i}><small>P{i+1}</small><b>{p}</b></span>)}</div><p>Sprint points go to the top eight: {points.sprint.join(', ')}.</p><small>{points.note}</small></section>
   <section className="panel"><div className="eyebrow">DRIVER PROFILE</div><h2>Max at a glance</h2><div className="facts">{maxFacts.map(f=><div key={f.label}><strong>{f.value}</strong><span>{f.label}</span><small>{f.detail}</small></div>)}</div></section></div>
  <h2 className="block-title">Tyres decide races</h2>
  <div className="tyre-row">{tyres.map(t=><article key={t.name} className="tyre"><i style={{borderColor:t.colour}}/><h3>{t.name}</h3><p>{t.text}</p></article>)}</div><div className="notice">{tyreNote}</div>
  <h2 className="block-title">Technology that matters</h2>
  <div className="step-grid three">{technology.map(t=><article className="step-card" key={t.title}><h3>{t.title}</h3><p>{t.text}</p></article>)}</div>
  <h2 className="block-title">Flags</h2>
  <div className="flag-row">{flags.map(f=><article key={f.name} className="flag"><i style={{background:f.colour}}/><div><h3>{f.name}</h3><p>{f.text}</p></div></article>)}</div>
  <div className="two-col"><section className="panel"><div className="eyebrow">THE TEAM</div><h2>Red Bull Racing</h2><ol className="mini-timeline">{redBull.map(r=><li key={r.year}><strong>{r.year}</strong><span>{r.text}</span></li>)}</ol></section>
   <section className="panel"><div className="eyebrow">CONTEXT</div><h2>Three eras</h2><ol className="mini-timeline">{eras.map(e=><li key={e.name}><strong>{e.years}</strong><span><b>{e.name}.</b> {e.text}</span></li>)}</ol></section></div>
  <section className="panel fan"><div className="fan-copy"><div className="eyebrow">FANS</div><h2>{fanCulture.title}</h2><p>{fanCulture.text}</p></div><Photo slot="fans" keywords={['zandvoort','dutch','fans']} offset={3} label="Dutch Grand Prix"/></section>
  <h2 className="block-title">Paddock glossary</h2>
  <dl className="glossary">{glossary.map(([t,d])=><div key={t}><dt>{t}</dt><dd>{d}</dd></div>)}</dl>
  <div className="notice">General Formula 1 background for newcomers. Regulations change from season to season, so check the FIA sporting regulations for the exact current rules.</div>
 </div>
}
