# The Verstappen File — Ultimate

A multi-page React 19 + TypeScript racing archive, interactive 3D garage, recorded telemetry lab, strategy simulator and Groq race engineer. Frontend and Express API are designed for **one Vercel project and one domain**.

## Start on Windows

1. Install **Node.js 22 or newer**.
2. Extract this ZIP into a normal folder.
3. Double-click **start.bat**. It checks Node/npm, installs locked dependencies if needed, copies `.env.example`, runs TypeScript validation, starts the API and frontend together, and opens `http://localhost:5173` when ready.
4. Keep the terminal open. Press **Ctrl+C** to stop.

Or use a terminal:

```sh
npm ci
npm run dev
```

The default local server uses the same exported Express application as production, followed by Vite middleware. No Vercel account, Python, Docker or separate service is required for ordinary local use.

## Pages

| URL | Experience |
|---|---|
| `/` | Cinematic 3D car, starting lights, historical milestones and next published race |
| `/biography` | Interactive navigation through an expanded chronological driver story |
| `/garage` | Four conceptual cars, orbit, spin, explode, hotspots, wireframe, airflow, presets, comparison, fullscreen and PNG capture |
| `/legacy` | Interactive trophy sculpture and championship season gallery |
| `/f1-101` | Beginner-friendly Formula 1 guide: race weekends, points, tyres, technology, flags, Red Bull history, eras and glossary |
| `/race-center` | Calendar, sessions, race/qualifying/sprint classifications, driver and constructor standings |
| `/telemetry` | Two recorded Bahrain 2023 Q laps, replay/scrub, channel selection, sectors and interpolated delta |
| `/circuits` | Austria, Miami and Monza artistic circuit notebooks and animated markers |
| `/strategy` | One/two-stop simulation, weather, fuel, traffic, SC/VSC, compound and uncertainty controls |
| `/career` | Searchable Verstappen race archive and full selected-race classification |
| `/comparisons` | Season driver comparisons, race points progression and qualifying head-to-head |
| `/records` | Historical records and win curve |
| `/ai-engineer` | Groq answers with server-retrieved context, deterministic fallback and conversation export |

The top-right menu exposes every page. Original `.html` paths redirect to their replacement routes. Motion can be disabled in the footer; device reduced-motion preferences are respected on first use.

## Technology

React 19, strict TypeScript, Vite, Tailwind CSS, React Router, Three.js, React Three Fiber, Drei, GSAP/ScrollTrigger, Motion, ECharts, TanStack Query, Zustand, Lucide and Zod. Backend: Node.js, Express 5, Helmet, express-rate-limit and Zod. Validation: TypeScript, ESLint, Vitest, Supertest, Playwright.

Dependencies are locked in `package-lock.json`. Three.js and charts are split from ordinary page code. Telemetry is delivered as small static JSON files rather than through a function. No external font CDN, model CDN, paid database, WebSocket service or background process is required.

## One-project Vercel deployment

1. Create a GitHub repository containing the **contents of this project folder**. Do not commit `.env` or `node_modules`.
2. Import the repository into Vercel. Select the repository root (`.`).
3. Use **Vite** as the framework preset, `npm run build` as the build command, and `dist` as the output directory. Install command: `npm ci`. Use Node.js 22 or newer.
4. Add server environment variables from the table below. Add `GROQ_API_KEY` only if using Groq.
5. Deploy. The root `vercel.json` routes `/api/*` to the default-exported Express application in `api/index.ts`; static assets come from `dist`; other application URLs receive `index.html` for React Router.
6. Check `/api/health`, `/api/calendar?season=2024`, `/api/results?season=2024&round=1` and every page. Refresh `/garage` directly. Confirm `/api/not-a-route` returns **JSON 404**, not HTML.
7. Verify the AI assistant after setting your key. If the key or provider is unavailable, the UI explicitly uses a deterministic summary.

**No deployment was performed as part of this ZIP delivery.** The configuration and production build are supplied; authenticated Vercel deployment/routing and browser verification must still be completed in your account. See `docs/TESTING.md` for the exact evidence and limits.

For Vercel's local routing harness:

```sh
npx vercel login
npx vercel link
npm run dev:vercel
```

This first-time login/link is optional for normal local use, required to verify with Vercel CLI. Do not use the Express-only preset: this repository contains a Vite frontend plus an exported Node function, with a single root config. The Express app has no production port listener.

Documentation references: [Vite on Vercel](https://vercel.com/docs/frameworks/frontend/vite), [Express on Vercel](https://vercel.com/docs/frameworks/backend/express), [Vercel configuration](https://vercel.com/docs/project-configuration/vercel-json).

## Environment

| Variable | Default / purpose |
|---|---|
| `GROQ_API_KEY` | Optional server-side Groq secret; never use a `VITE_` prefix |
| `GROQ_MODEL` | `llama-3.3-70b-versatile`; set a model supported by your Groq account |
| `JOLPICA_BASE_URL` | `https://api.jolpi.ca/ergast/f1` |
| `DATA_FALLBACK_ENABLED` | `true`; allow same-season immutable snapshots |
| `CACHE_TTL_SECONDS` | `3600`; warm-cache TTL, bounded to 30–86400 seconds |
| `DATA_OFFLINE` | `false`; set `true` locally to verify fallback; do not enable for normal production |

Groq is called only by the Express function. Conversation content and selected racing context are transmitted to Groq when configured; no conversations are stored by this app on the server. Responses are currently non-streaming. No third-party AI provider integration exists.

## API

| Method/path | Input |
|---|---|
| GET `/api/health` | Health and AI configuration flag; no secrets |
| GET `/api/calendar` | `season`, optional `round` |
| GET `/api/results` | `season`, optional `round` |
| GET `/api/standings` | `season` |
| GET `/api/constructors` | `season` |
| GET `/api/qualifying` | `season`, optional `round` |
| GET `/api/sprint` | `season`, optional `round` |
| GET `/api/telemetry` | Static telemetry manifest location |
| POST `/api/strategy` | See `shared/strategy.ts` for validated inputs |
| POST `/api/ai/chat` | `message`, `season`, optional `round`, bounded `history` |

Race responses include `source`, `sourceUrl`, `updatedAt`, `partial`, and a fallback warning where relevant. All API errors use JSON. Inputs are validated; JSON bodies are bounded to 24 KiB. General requests are limited to 90/minute and AI to 10/minute **per warm instance**. Vercel Firewall rules can enforce broader production quotas; no distributed-rate-limit guarantee is claimed.

## Structure

| Directory | Responsibility |
|---|---|
| `api/index.ts` | Vercel Node function exporting Express |
| `backend/src/app.ts` | API, validation, headers, rate limits and Groq grounding |
| `backend/src/providers/` | Jolpica retrieval, pagination, deduplication, cache and snapshot fallback |
| `frontend/src/pages/` | Distinct routed experiences |
| `frontend/src/scenes/` | Procedural car and trophy scenes |
| `frontend/src/components/` | Charts, classification tables and shared UI |
| `frontend/src/services/` | Same-origin API client and query caching |
| `frontend/src/stores/` | Rendering quality and motion settings |
| `frontend/src/styles/` | Responsive visual system |
| `frontend/public/datasets/` | Recorded telemetry chunks and manifest |
| `datasets/historical/` | Bundled race snapshots with provenance |
| `shared/` | Data schemas, editorial content, deterministic strategy engine |
| `scripts/` | Local server, preview and dataset ingestion |
| `tests/` | API/data/strategy tests and browser scenarios |
| `docs/` | Migration inventory, data definitions and test report |

## Commands

```sh
npm run typecheck
npm run lint
npm test
npm run build
npm run preview
npx playwright install chromium
npm run test:e2e
npm run data:update -- 2026
```

`npm run preview` serves the production build and API locally at port 5173. The delivered source includes no `node_modules`; installation is required. See `docs/DATA.md` for dataset update procedure, attribution and limits.

## Important implementation limits

- Cars and trophy are conceptual procedural art, not licensed manufacturer CAD or official trophy replicas. Airflow is illustrative, not CFD.
- Circuit outlines are artistic. Verified turn/DRS/elevation geometry and flyovers are not available.
- Telemetry is limited to the two bundled qualifying laps. GPS racing lines, exact real-time playback and live feeds are not provided.
- The biography/record collection is intentionally scoped through 2024. Recent race results/standings are provider-backed and timestamped.
- Career points in comparisons are race-only; use championship standings for totals including sprints and adjustments.
- The bounded strategy model runs synchronously in the browser and is also available through the API. Its Monte Carlo interval is illustrative and not calibrated.
- AI uses server-selected structured racing context; general engineering facts beyond that context may be unavailable. It has no arbitrary web browsing, persistent history or multi-step tool agent.
- Cache and rate-limit state are ephemeral across Vercel instances. A paid persistent store is not needed for basic operation.
- WebGL needs a compatible browser/GPU. A text fallback is available if scene creation fails.

## Troubleshooting

**Blank page / failed imports:** run `npm ci`, then `npm run build`; use Node 22+.

**API response is HTML:** verify the root `vercel.json` and Vite preset. `/api/*` must be matched before the frontend fallback. Do not deploy only the `frontend` folder.

**AI shows deterministic summary:** the key is absent, invalid, rate-limited, the model is unsupported, or Groq timed out. Set server environment variables and redeploy. No key is needed for archive/garage/simulation.

**Data says bundled:** Jolpica could not be validated/reached within the bounded request budget. Check provider availability, leave fallback enabled, or update/redeploy snapshots.

**Port 5173 occupied:** stop another local instance, then rerun `start.bat`.

**Slow 3D:** choose low quality, stop spin, or enable reduced motion. Capture/fullscreen support depends on browser permissions.

**Browser tests cannot start:** install Chromium with the command above on a network that can reach Playwright's browser CDN. Missing browser executables are not passing tests.

## Max Verstappen photos

Photos appear on the home page, biography chapters, legacy seasons, garage, circuits, records and the F1 guide. No image files are bundled, so those slots show a styled "33" placeholder until you add photos.

**Fastest way (needs internet):**

```sh
npm run photos:fetch          # downloads 24 freely licensed photos from Wikimedia Commons
npm run photos:fetch -- 40    # or choose how many
```

The script saves JPEGs to `frontend/public/images/max/` and writes `manifest.json` with each photo's author, licence and source link. Credits are displayed under every image; keep them, because Creative Commons licences require attribution.

**Matching:** each slot first uses a photo whose `slots` list names it (for example `"slots":["home-1"]`), then the photo whose title best matches the slot's keywords (year, circuit, car), then any remaining photo.

**Your own photos:** copy them into `frontend/public/images/max/` and add entries to `manifest.json`:

```json
{"photos":[{"file":"my-photo.jpg","title":"Max Verstappen 2023 Monza","credit":"Photographer name","license":"Licence","slots":["home-1"]}]}
```

Only use images you have the right to publish. Official Formula 1 and agency photos are copyrighted.

After changing anything, run `npm run build` again before deploying a production build (the bundled `dist` was not regenerated for this update).
