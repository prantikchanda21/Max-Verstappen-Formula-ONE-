import {readFile,writeFile} from 'node:fs/promises';
import {fetchPages} from '../backend/src/providers/pagination';
const season=Number(process.argv[2]||new Date().getUTCFullYear());
if(!Number.isInteger(season)||season<1950||season>new Date().getUTCFullYear()+1)throw Error('Provide a valid season');
const file=new URL('../datasets/historical/snapshots.json',import.meta.url);
const snapshots:Record<string,unknown>=JSON.parse(await readFile(file,'utf8'));
for(const [kind,path] of Object.entries({calendar:'races',results:'results',standings:'driverStandings',constructors:'constructorStandings',qualifying:'qualifying',sprint:'sprint'})){
 const url=`https://api.jolpi.ca/ergast/f1/${season}/${path}.json?limit=100`;
 const payload=await fetchPages(url,async u=>{const r=await fetch(u,{signal:AbortSignal.timeout(15000)});if(!r.ok)throw Error(`HTTP ${r.status}; wait before retrying ingestion`);return r.json()});
 snapshots[`${season}/${kind}`]={url,retrievedAt:new Date().toISOString(),payload,pagination:'All pages merged; limit records total.'};
 console.log(season,kind,payload.MRData.total);
 await new Promise(resolve=>setTimeout(resolve,1100));
}
await writeFile(file,JSON.stringify(snapshots));
console.log('Snapshots saved. Run tests/build, then redeploy.');
